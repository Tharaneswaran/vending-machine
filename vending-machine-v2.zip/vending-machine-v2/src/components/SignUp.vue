<template>
<v-card
  elevation="2"
  shaped
  width="450px"
>
<br>
<h2 style="text-align: center;">
  Please enter the required details...
</h2>
<br>
<v-row  class="d-flex justify-center mb-6">
  <v-col   cols="18"
            sm="10"
            md="10">
    
    <v-text-field
    label="uid"

    filled
    dense
    rounded 
    v-model = "uid"
></v-text-field>            
    <v-text-field
    label="Username"
    placeholder="Enter your username"
    filled
    dense
    rounded 
    v-model = "userName"
></v-text-field>

<v-text-field
    label="PIN"
    placeholder="Enter your PIN"
    filled
    dense
    rounded 
    v-model = "pin"
    >
</v-text-field>

<v-text-field
    label="Confirm PIN"
    placeholder="Re-enter your PIN"
    filled
    dense
    rounded 
    v-model = "cPin"
    >
</v-text-field>

<div class="d-flex justify-center mb-6">

<v-btn
  color="purple"
  elevation="4"
  @click = "signUp({uid,userName,pin})"
>
Sign Up
</v-btn>
</div>
  </v-col>
</v-row>

   


</v-card>
</template>

<script>
import axios from 'axios';
export default {
    name: 'SignUp',
    data: () => ({
        uid : "",
        userName : "",
        pin : 0,
        cPin : 0,

    }),
    mounted : async function () {
    this.instance =  axios.create({ baseURL: "http://127.0.0.1:3333" , headers:{'Content-type' : "application/json",}})
  },
    methods:{
      async clearForm(){
        this.uid = "",
        this.userName = "",
        this.pin = 0,
        this.cPin = 0
      },
      async signUp({uid,userName,pin}){
        const data = await this.instance.post("/registerRfid",{uid,userName,pin}).then((res)=> res.data)
        console.log(data.data);
        const user = data.data
        if(data['success'])
          this.$router.go()
          this.clearForm()
      },
    }
}
</script>