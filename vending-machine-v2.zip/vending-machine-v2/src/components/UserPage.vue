<template>
    <div class="d-flex justify-center mb-6">
        
        <v-card
elevation="2"
  shaped
  width="1000px"
  class="ma-3 text-center"
  >
<br>
<v-row>
<v-col>
    <h3>
        Your account balance : {{user.balance}}
      </h3>
      <br>
</v-col>
</v-row>
<v-row>
<v-col>
    <v-row>
        <v-col>
            <h3>
        Click here to top up 
      </h3>
      <v-text-field style="display: none;" name="userName" v-model = "userName" :value= "userNameFromDb.user_name"></v-text-field>
      <br>
      <v-text-field
      label="Enter amount"
      placeholder="Enter amount"
      type="number"
      filled 
      dense
    rounded 
    v-model = "amount"
  >
        
      </v-text-field>
        </v-col>
        <v-col>
            <v-btn
      style="background-color: purple ;color: white;"
        elevation="4"
        @click = "topUp({userName,amount})">
      Top Up 
      </v-btn>
        </v-col>
    </v-row>
    
    
</v-col>
<v-col>

    <v-row>
        <v-col>
            <h3>
        Click here to block card 
      </h3>
        </v-col>
        <v-col>
            <v-btn
      style="background-color: purple ;color: white;"
        elevation="4"
        @click = "boolean = !boolean">
      Block Card 
      </v-btn>
        </v-col>
    </v-row>
</v-col>

</v-row>
<br>
</v-card>
    </div>




</template>
<script>
import axios from 'axios';
export default {
    name: 'UserPage',
    props : ['user'],
    data: () => ({
        userName : "",
        amount : 0,
        userData : {},
        userNameFromDb : ""
    }),
    created(){
      console.log(this.user);
      this.userNameFromDb = this.user
      this.userName = this.userNameFromDb.user_name
    },
    async clearForm(){
        this.amount = ""
      },
    mounted : async function () {
    this.instance =  axios.create({ baseURL: "http://127.0.0.1:3333" , headers:{'Content-type' : "application/json",}})
    },
    methods : {
      async topUp({userName ,amount}){
        console.log({userName,amount});
        const data = await this.instance.post("/topUpCard",{userName,amount}).then((res)=> res.data)
        console.log(data.data);
        const user = data.data
        if(data['success']){
        this.userData=user
        this.user = this.userData
        this.userName = this.userNameFromDb.user_name
      }
      this.clearForm()
      }
    }
}


    
</script>