import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class TopupValidator {
  constructor(protected ctx: HttpContextContract) {}

  public schema = schema.create({
    userName: schema.string([rules.exists({ table: 'rfids', column: 'user_name' })]),
    amount: schema.number([rules.unsigned()]),
  })

  public messages: CustomMessages = {}
}
