import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class SignInValidator {
  constructor(protected ctx: HttpContextContract) {}

  public schema = schema.create({
    userName: schema.string([
      rules.exists({ table: 'rfids', column: 'user_name' }),
      rules.maxLength(10),
    ]),
    pin: schema.number([rules.unsigned()]),
  })

  public messages: CustomMessages = {}
}
