import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { RfidRepo } from 'App/Repositories'
import { RfidValidator, SignInValidator, TopupValidator } from 'App/Validators'

export default class RfidsController {
  public async cardRegistration({ request }: HttpContextContract) {
    const payload = await request.validate(RfidValidator)
    console.log(payload)    
    const data = await RfidRepo.register(payload)
    return { success: true, ...data }
  }

  public async signIn({ request }: HttpContextContract) {
    const { userName, pin } = await request.validate(SignInValidator)
    const data = await RfidRepo.signIn(userName, pin)
    return { ...data }
  }

  public async cardTopup({ request }: HttpContextContract) {
    const { userName, amount } = await request.validate(TopupValidator)
    const data = await RfidRepo.topUp(userName, amount)
    return { success: true, ...data }
  }
}
